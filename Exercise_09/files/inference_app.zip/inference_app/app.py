from base64 import b64encode
import os
from grpc.beta import implementations
import tensorflow as tf
import skimage.io
from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2
import json
import requests
from flask import Flask, render_template, send_from_directory, globals
from flask_socketio import SocketIO

app = Flask(__name__)
app.config['SECRET_KEY'] = 'rn-0n75(s^3ku^qrnafm*ak$lb_=jncll_)_ol^thqhq8u+88q'
socketio = SocketIO(app)

service = (json.loads(os.getenv('VCAP_SERVICES', '')))['ml-foundation'][0]

MODEL_NAME = str(os.getenv('MODEL_NAME', ''))
client_id = str(service['credentials']['clientid'])
client_secret = str(service['credentials']['clientsecret'])
authentication_url = str(service['credentials']['url']) + "/oauth/token"


def get_access_token():
    querystring = {"grant_type": "client_credentials"}
    auth = b64encode(b"" + client_id + ":" + client_secret).decode("ascii")
    headers = {
        'Cache-Control': "no-cache",
        'Authorization': "Basic %s" % auth
    }
    response = requests.request("GET", authentication_url, headers=headers, params=querystring)
    return 'Bearer ' + json.loads(response.text)['access_token']


def metadata_transformer(metadata):
    additions = []
    token = get_access_token()
    additions.append(('authorization', token))
    return tuple(metadata) + tuple(additions)


@app.route('/do_inference', methods=['POST'])
def main():
    deployment_url = str(service['credentials']['serviceurls']['DEPLOYMENT_API_URL']) + "/api/v2/modelServers"
    querystring = {"modelName": MODEL_NAME}
    headers = {
        'Authorization': get_access_token(),
        'Cache-Control': "no-cache"
    }
    response = requests.request("GET", deployment_url, headers=headers, params=querystring)
    model_info = json.loads(response.text)
    latest_version = [0, 0]
    for index, model in enumerate(model_info["modelServers"]):
        if int(model["specs"]["models"][0]["modelVersion"]) > latest_version[0]:
            latest_version = [int(model["specs"]["models"][0]["modelVersion"]), index]
    model_host = model_info["modelServers"][latest_version[1]]["endpoints"][0]
    credentials = implementations.ssl_channel_credentials(root_certificates=str(model_host["caCrt"]))
    channel = implementations.secure_channel(str(model_host["host"]),
                                             int(model_host["port"]), credentials)
    stub = prediction_service_pb2.beta_create_PredictionService_stub(channel, metadata_transformer=metadata_transformer)
    uploaded_files = globals.request.files.getlist('file')
    data = skimage.io.imread(uploaded_files[0])

    req = predict_pb2.PredictRequest()
    req.model_spec.name = MODEL_NAME
    req.model_spec.signature_name = 'predict_images'
    req.inputs["images"].CopyFrom(
        tf.contrib.util.make_tensor_proto(data, shape=[1, data.size], dtype="float32"))
    res = str(stub.Predict(req, 150)).split('}')[3].split('\n')
    res.pop(11)
    res.pop(0)
    out_val = 0.0
    out = 0
    for i, estimate in enumerate(res):
        if float(estimate[14:]) > out_val:
            out_val = float(estimate[14:])
            out = i
    return "Result: " + str(out)


@app.route('/', methods=["GET"])
def serve_index():
    return render_template('index.html')


@app.route('/<path:path>')
def static_proxy(path):
    if ".js" in path or "i18n" in path or "favicon" in path or ".json" in path or ".css" in path:
        return send_from_directory('templates', path)
    else:
        return render_template(path)


port = os.getenv('PORT', 5000)
if __name__ == '__main__':
    app.debug = not os.getenv('PORT')
    socketio.run(app, host='0.0.0.0', port=int(port))
